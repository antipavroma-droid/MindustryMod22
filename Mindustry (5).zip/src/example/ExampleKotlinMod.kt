package mymod

import arc.Events
import arc.scene.ui.TextButton
import arc.util.Log
import mindustry.Vars
import mindustry.game.EventType.ClientLoadEvent
import mindustry.mod.Mod
import mindustry.ui.Styles

class ExampleKotlinMod : Mod() {

    // Массив доступных скоростей
    private val speeds = floatArrayOf(1f, 2f, 4f, 8f, 16f)
    private var currentSpeedIndex = 0

    init {
        Log.info("Загружен мод на ускорение времени!")

        // Ждем, пока загрузится клиент игры и интерфейс
        Events.on(ClientLoadEvent::class.java) {
            buildSpeedButton()
        }
    }

    private fun buildSpeedButton() {
        // Находим главную верхнюю таблицу UI, где лежат схемы и меню
        // Она автоматически учитывает настройки масштаба (90%) и выравнивание
        val topTable = Vars.ui.hudfrag.inv.table
        
        // Создаем контейнер для нашей кнопки, чтобы задать ей четкие размеры
        topTable.row() // Переносим на новую строку, чтобы встала ровно ПОД схемами
        
        topTable.table { cellTable ->
            val speedButton = cellTable.button("1x", Styles.defaultt) {
                // Логика клика
                currentSpeedIndex = (currentSpeedIndex + 1) % speeds.size
                val newSpeed = speeds[currentSpeedIndex]
                Vars.state.setSpeedMultiplier(newSpeed)
                
                // Обновляем текст (используем анонимную кнопку для доступа к её тексту)
                (cellTable.children.first() as TextButton).setText("${newSpeed.toInt()}x")
            }.size(70f, 45f).padLeft(6f).padTop(4f).get()
            
            // Левое выравнивание внутри ячейки
            cellTable.left()
        }.left() // Прижимаем всю эту строку к левому краю экрана
    }


    override fun loadContent() {
        // Здесь чисто, так как новые блоки мы не добавляем
    }
}